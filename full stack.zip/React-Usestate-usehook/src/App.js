import logo from './logo.svg';
import './App.css';
import Action from './action';
import Actionfun from './actionfun';

function App() {
  return (
    <div className="App">
     <Action/> 
     <Actionfun/> 
      </div>
  );
}

export default App;
