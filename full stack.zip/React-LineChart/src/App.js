import logo from './logo.svg';
import './App.css';
import Linechart1  from './Linechart1';
import { LineChart } from 'recharts';


function App() {
  return (
    <div className="App">
      <Linechart1/>

    </div>
  );
}

export default App;
