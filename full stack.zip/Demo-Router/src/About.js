import React, { Component } from 'react'

export default function About(){
    return(
          <h2>Vanakkam to About</h2>
    );
}