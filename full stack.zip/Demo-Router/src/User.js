import React, { Component } from 'react'
export default function User(){
    return (
        <h3>User Page</h3>
    );
}